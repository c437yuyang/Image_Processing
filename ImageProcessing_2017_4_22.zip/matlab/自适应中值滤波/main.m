clc,clear all,close all
lena = imread('..\0.jpg');
imshow(lena);