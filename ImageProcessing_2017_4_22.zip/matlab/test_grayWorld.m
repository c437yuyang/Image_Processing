I=imread('lena.jpg');
y=GrayWorld(I);
figure(1);imshow(I);
figure(2);imshow(y,[]);
